import cv2
import numpy as np
import os
import matplotlib.pyplot as plt

ime = "rgb_test" 

slika_path = f"validacija_slike/{ime}.png"
maska_path = f"validacija_maske/{ime}.png"
pred_path = f"validacija_rezultati/predikcija_{ime}.png"
output_path = f"validacija_rezultati/overlay_{ime}.png"

slika = cv2.imread(slika_path)
maska = cv2.imread(maska_path, cv2.IMREAD_GRAYSCALE)
pred = cv2.imread(pred_path, cv2.IMREAD_GRAYSCALE)

if slika is None or maska is None or pred is None:
    print(" Greška pri učitavanju. Provjeri imena i putanje.")
    exit()

slika = cv2.resize(slika, (256, 256))
maska = cv2.resize(maska, (256, 256))
pred = cv2.resize(pred, (256, 256))

slika_rgb = cv2.cvtColor(slika, cv2.COLOR_BGR2RGB)

def apply_overlay(base, mask, color, alpha=0.5):
    overlay = base.copy()
    mask_bool = mask > 127
    overlay[mask_bool] = ((1 - alpha) * base[mask_bool] + alpha * np.array(color)).astype(np.uint8)
    return overlay

maska_overlay = apply_overlay(slika_rgb, maska, color=[255, 0, 0], alpha=0.5)
pred_overlay = apply_overlay(slika_rgb, pred, color=[0, 255, 0], alpha=0.5)

kombinacija = np.hstack([slika_rgb, maska_overlay, pred_overlay])

cv2.imwrite(output_path, cv2.cvtColor(kombinacija, cv2.COLOR_RGB2BGR))
plt.imshow(kombinacija)
plt.title("Original | Maska (crveno) | Predikcija (zeleno)")
plt.axis("off")
plt.show()
print(f" Spaseno kao: {output_path}")
