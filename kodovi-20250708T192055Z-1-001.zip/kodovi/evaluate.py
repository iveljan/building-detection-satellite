import torch
import torchvision.transforms as T
from torch.utils.data import DataLoader
from spacenet_dataset import SpaceNetDataset
from unet_model import UNet
import numpy as np

#  Parametri
MODEL_PATH = 'unet_epoch10.pth'
IMAGE_DIR = 'processed/images'
MASK_DIR = 'processed/masks'
DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'
BATCH_SIZE = 4

#  Dataset i transform
transform = T.ToTensor()
dataset = SpaceNetDataset(IMAGE_DIR, MASK_DIR, transform=transform)
loader = DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=False)

#  Učitaj model
model = UNet(in_channels=3, out_channels=1).to(DEVICE)
model.load_state_dict(torch.load(MODEL_PATH, map_location=DEVICE))
model.eval()

#  IoU funkcija
def compute_iou(preds, targets, threshold=0.5):
    preds = (preds > threshold).float()
    intersection = (preds * targets).sum(dim=(1, 2, 3))
    union = ((preds + targets) >= 1).float().sum(dim=(1, 2, 3))
    iou = (intersection + 1e-6) / (union + 1e-6)
    return iou.mean().item()

#  Evaluacija
total_iou = 0
count = 0

with torch.no_grad():
    for images, masks in loader:
        images = images.to(DEVICE)
        masks = masks.to(DEVICE)
        preds = model(images)
        iou = compute_iou(preds, masks)
        total_iou += iou
        count += 1

avg_iou = total_iou / count
print(f" Prosječni IoU: {avg_iou:.4f}")
