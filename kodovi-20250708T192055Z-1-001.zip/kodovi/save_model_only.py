import torch
from unet_model import UNet

MODEL_PATH = 'unet_epoch10.pth'

model = UNet(in_channels=3, out_channels=1)

try:
    torch.save(model.state_dict(), MODEL_PATH)
    print(f" Model sacuvan kao {MODEL_PATH}")
except Exception as e:
    print(" Neuspjesno:", e)

