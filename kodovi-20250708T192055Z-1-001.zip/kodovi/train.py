import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from torchvision import transforms
from spacenet_dataset import SpaceNetDataset
from unet_model import UNet
from tqdm import tqdm


IMAGE_DIR = 'processed/images'
MASK_DIR = 'processed/masks'

# Hiperparametri
BATCH_SIZE = 4
EPOCHS = 10
LR = 1e-3
DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'

# Transformacija (Tensor only, već su 256x256)
transform = transforms.ToTensor()

#  Dataset i Loader
dataset = SpaceNetDataset(IMAGE_DIR, MASK_DIR, transform=transform)
loader = DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=True)

# Model, loss, optimizator
model = UNet(in_channels=3, out_channels=1).to(DEVICE)
loss_fn = nn.BCELoss()
optimizer = optim.Adam(model.parameters(), lr=LR)

#  Trening petlja
for epoch in range(EPOCHS):
    model.train()
    total_loss = 0.0

    for images, masks in tqdm(loader):
        images = images.to(DEVICE)
        masks = masks.to(DEVICE)

        preds = model(images)
        loss = loss_fn(preds, masks)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        total_loss += loss.item()

    print(f"[Epoch {epoch+1}/{EPOCHS}] Loss: {total_loss / len(loader):.4f}")

torch.save(model.state_dict(), 'unet_epoch10.pth')
print(" Model sačuvan kao unet_epoch10.pth")
