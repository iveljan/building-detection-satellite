import os
import rasterio
import geopandas as gpd
import numpy as np
from rasterio.features import rasterize
from PIL import Image
from tqdm import tqdm

RGB_PATH = 'RGB-PanSharpen'
GEOJSON_PATH = os.path.join('geojson', 'buildings')
OUTPUT_IMG = 'processed/images'
OUTPUT_MASK = 'processed/masks'
PATCH_SIZE = 256

os.makedirs(OUTPUT_IMG, exist_ok=True)
os.makedirs(OUTPUT_MASK, exist_ok=True)

def process_image(image_name):
    image_path = os.path.join(RGB_PATH, image_name)

    img_id = image_name.split('_')[-1].replace('.tif', '')  
    geojson_filename = f'buildings_AOI_3_Paris_{img_id}.geojson'
    geojson_path = os.path.join(GEOJSON_PATH, geojson_filename)

    if not os.path.exists(geojson_path):
        raise FileNotFoundError(f'Nema geojson: {geojson_filename}')

    with rasterio.open(image_path) as src:
        image = src.read([1, 2, 3])
        image = np.transpose(image, (1, 2, 0))
        transform = src.transform
        height, width = image.shape[:2]

    gdf = gpd.read_file(geojson_path)
    geometries = gdf['geometry']

    mask = rasterize(
        [(geom, 1) for geom in geometries],
        out_shape=(height, width),
        transform=transform,
        fill=0,
        dtype='uint8'
    )

    image = (image / 255.0).astype(np.float32)
    return image, mask

def save_patches(image, mask, base_name):
    h, w = image.shape[:2]
    for i in range(0, h, PATCH_SIZE):
        for j in range(0, w, PATCH_SIZE):
            img_patch = image[i:i+PATCH_SIZE, j:j+PATCH_SIZE]
            mask_patch = mask[i:i+PATCH_SIZE, j:j+PATCH_SIZE]

            if img_patch.shape[0] != PATCH_SIZE or img_patch.shape[1] != PATCH_SIZE:
                continue

            img_patch = (img_patch * 255).astype(np.uint8)
            mask_patch = (mask_patch * 255).astype(np.uint8)

            img_name = f"{base_name}_{i}_{j}.png"
            Image.fromarray(img_patch).save(os.path.join(OUTPUT_IMG, img_name))
            Image.fromarray(mask_patch).save(os.path.join(OUTPUT_MASK, img_name))

for fname in tqdm(os.listdir(RGB_PATH)):
    if not fname.endswith('.tif'):
        continue
    try:
        image, mask = process_image(fname)
        base_name = os.path.splitext(fname)[0]
        save_patches(image, mask, base_name)
    except Exception as e:
        print(f"Greška pri obradi {fname}: {e}")
