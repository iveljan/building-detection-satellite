import os
import torch
from torch.utils.data import DataLoader, Dataset
import torch.nn as nn
import numpy as np
import cv2
import matplotlib.pyplot as plt
from unet_model import UNet  

val_image_dir = "validacija_slike"
val_mask_dir = "validacija_maske"
output_dir = "validacija_rezultati"
model_path = "unet_epoch10.pth"

os.makedirs(val_image_dir, exist_ok=True)
os.makedirs(val_mask_dir, exist_ok=True)
os.makedirs(output_dir, exist_ok=True)

if len(os.listdir(val_image_dir)) == 0 or len(os.listdir(val_mask_dir)) == 0:
    print("\nUpozorenje: Folderi za validaciju su prazni.")
    print("Dodaj slike u 'validacija_slike/' i odgovarajuće maske u 'validacija_maske/' prije pokretanja.\n")
    exit()

class SegmentationDataset(Dataset):
    def __init__(self, image_paths, mask_paths):
        self.image_paths = image_paths
        self.mask_paths = mask_paths

    def __len__(self):
        return len(self.image_paths)

    def __getitem__(self, idx):
        img_path = self.image_paths[idx]
        mask_path = self.mask_paths[idx]

        image = cv2.imread(img_path)
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        image = cv2.resize(image, (256, 256))
        image = image / 255.0
        image = torch.tensor(image, dtype=torch.float).permute(2, 0, 1)

        mask = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE)
        mask = cv2.resize(mask, (256, 256))
        mask = mask / 255.0
        mask = torch.tensor(mask, dtype=torch.float).unsqueeze(0)

        return image, mask, img_path

def calculate_iou(pred_mask, true_mask, threshold=0.5):
    pred_mask = (pred_mask > threshold).astype(np.uint8)
    true_mask = (true_mask > 0.5).astype(np.uint8)
    intersection = np.logical_and(pred_mask, true_mask).sum()
    union = np.logical_or(pred_mask, true_mask).sum()
    if union == 0:
        return 1.0 if intersection == 0 else 0.0
    return intersection / union

val_image_paths = sorted([os.path.join(val_image_dir, f) for f in os.listdir(val_image_dir)])
val_mask_paths = sorted([os.path.join(val_mask_dir, f) for f in os.listdir(val_mask_dir)])
val_dataset = SegmentationDataset(val_image_paths, val_mask_paths)
val_loader = DataLoader(val_dataset, batch_size=1, shuffle=False)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = UNet()
model.load_state_dict(torch.load(model_path, map_location=device))
model.to(device)
model.eval()

criterion = nn.BCELoss()

total_loss = 0.0
ious = []

with torch.no_grad():
    for idx, (images, masks, img_paths) in enumerate(val_loader):
        images = images.to(device)
        masks = masks.to(device)

        outputs = model(images)
        loss = criterion(outputs, masks)
        total_loss += loss.item()

        preds = outputs > 0.5
        iou = calculate_iou(preds.cpu().numpy()[0, 0], masks.cpu().numpy()[0, 0])
        ious.append(iou)

        image_np = images.cpu().numpy()[0].transpose(1, 2, 0)
        mask_np = masks.cpu().numpy()[0, 0]
        pred_np = preds.cpu().numpy()[0, 0]

        base_name = os.path.basename(img_paths[0])
        base_name_no_ext = os.path.splitext(base_name)[0]

        pred_img = (pred_np * 255).astype(np.uint8)
        mask_img = (mask_np * 255).astype(np.uint8)
        image_rgb = (image_np * 255).astype(np.uint8)

        pred_path = os.path.join(output_dir, f"predikcija_{base_name_no_ext}.png")
        cv2.imwrite(pred_path, pred_img)

        kombinovana = np.hstack([
            cv2.resize(image_rgb, (256, 256)),
            cv2.cvtColor(mask_img, cv2.COLOR_GRAY2BGR),
            cv2.cvtColor(pred_img, cv2.COLOR_GRAY2BGR)
        ])
        komb_path = os.path.join(output_dir, f"vizualizacija_{base_name_no_ext}.png")
        cv2.imwrite(komb_path, kombinovana)

        print(f" Sačuvana: {komb_path} (IoU: {iou:.2f})")

avg_loss = total_loss / len(val_loader)
avg_iou = np.mean(ious)

print("\n Validacija završena.")
print(f" Prosječni Loss: {avg_loss:.4f}")
print(f" Prosječni IoU: {avg_iou:.4f}")
print(f" Rezultati spremljeni u folder: '{output_dir}/'\n")
