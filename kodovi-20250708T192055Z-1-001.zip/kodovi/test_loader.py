from spacenet_dataset import SpaceNetDataset
from torch.utils.data import DataLoader
import torchvision.transforms as T

# Transformacija (samo konverzija u tensor)
transform = T.Compose([
    T.ToTensor()
])

dataset = SpaceNetDataset(
    image_dir='processed/images',
    mask_dir='processed/masks',
    transform=transform
)

loader = DataLoader(dataset, batch_size=4, shuffle=True)

# Test: da vidimo dimenzije
for images, masks in loader:
    print("Batch slika:", images.shape)
    print("Batch maski:", masks.shape)
    break
